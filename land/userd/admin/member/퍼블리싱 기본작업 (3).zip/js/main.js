$(document).ready(function() {


});
$('.open-popup-link').magnificPopup({
  type:'inline',
  midClick: true // Allow opening popup on middle mouse click. Always set it to true if you don't provide alternative source in href.
});
// 애니메이션
$('.animate').scrolla({
	mobile: true,
	once: true
});
//슬라이더
var mySwiper = new Swiper('.slider_1', {
  // Optional parameters
  loop: true,

  // If we need pagination
  pagination: {
    el: '.paging_1',
  },

  // Navigation arrows
  navigation: {
    nextEl: '.btn_next1',
    prevEl: '.btn_prev1',
  },

})


var mySwiper = new Swiper('.slider_2', {
  // Optional parameters
  loop: true,

  // If we need pagination
  pagination: {
    el: '.paging_2',
  },

  // Navigation arrows
  navigation: {
    nextEl: '.btn_next2',
    prevEl: '.btn_prev2',
  },

})
